#include <iostream>
using namespace std;

int main() {
    int n;
    
    cout << "Enter the number of elements: ";
    cin >> n;

    int* arr = new int[n];

    cout << "Enter the elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int oddSum = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] % 2 != 0) {
            oddSum += arr[i];
        }
    }

    cout << "The sum of odd integers is: " << oddSum << endl;

    delete[] arr;

    return 0;
}

