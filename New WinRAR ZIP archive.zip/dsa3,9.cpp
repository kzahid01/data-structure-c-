#include <iostream>
#include <cmath>
using namespace std;

void menu();
int addition(int a, int b);
int subtraction(int a, int b);
int multiplication(int a, int b);
double division(int a, int b);
int power(int number, int pow);

int main() {
    menu();
    return 0;
}

void menu() {
    int choice, a, b;
    
    cout << "Calculator Menu:\n";
    cout << "1. Addition\n";
    cout << "2. Subtraction\n";
    cout << "3. Multiplication\n";
    cout << "4. Division\n";
    cout << "5. Power\n";
    cout << "Enter your choice: ";
    cin >> choice;

    if (choice >= 1 && choice <= 4) {
        cout << "Enter two numbers: ";
        cin >> a >> b;
    } else if (choice == 5) {
        cout << "Enter the base number and its exponent: ";
        cin >> a >> b;
    }

    switch (choice) {
        case 1:
            cout << "Result: " << addition(a, b) << endl;
            break;
        case 2:
            cout << "Result: " << subtraction(a, b) << endl;
            break;
        case 3:
            cout << "Result: " << multiplication(a, b) << endl;
            break;
        case 4:
            if (b == 0) {
                cout << "Error: Division by zero!" << endl;
            } else {
                cout << "Result: " << division(a, b) << endl;
            }
            break;
        case 5:
            cout << "Result: " << power(a, b) << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
    }
}

int addition(int a, int b) {
    return a + b;
}

int subtraction(int a, int b) {
    return a - b;
}

int multiplication(int a, int b) {
    return a * b;
}

double division(int a, int b) {
    return static_cast<double>(a) / b;
}

int power(int number, int pow) {
    return static_cast<int>(std::pow(number, pow));
}

