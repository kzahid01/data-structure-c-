#include <iostream>
using namespace std;

class Stack {
    int top;
    int array[12];  // Array size fixed at 12

public:
    // Constructor to initialize 'top'
    Stack() {
        top = -1;
    }

    // Push function to add an element to the stack
    void push(int x) {
        if (top >= 11) {  // Check for stack overflow (index 11 is the max for size 12)
            cout << "Stack overloaded" << endl;
            return;
        }
        array[++top] = x;
        cout << x << " pushed onto stack" << endl;
    }

    // Pop function to remove the top element from the stack
    void pop() {
        if (top < 0) {  // Check for stack underflow
            cout << "Stack underflow" << endl;
            return;
        }
        cout << array[top--] << " popped from stack" << endl;
    }

    // Peek function to get the top element without removing it
    int peek() {
        if (top < 0) {  // Check if the stack is empty
            cout << "-1 (Stack is empty)" << endl;
            return -1;
        }
        return array[top];
    }

    // Function to check if the stack is empty
    bool empty() {
        return top < 0;
    }
};

int main() {
    Stack s;  // Create a stack object

    s.push(53);
    s.push(52);
    s.push(56);

    // Output the top element
    cout << "Top element is: " << s.peek() << endl;

    s.pop();  // Remove the top element

    // Output the top element after pop
    cout << "Top element after pop is: " << s.peek() << endl;

    // Check if the stack is empty
    if (s.empty()) {
        cout << "Stack is empty" << endl;
    } else {
        cout << "Stack is not empty" << endl;
    }

    return 0;
}

