#include <iostream>
using namespace std;

int main() {
    int size, item, found = -1;

    cout << "Enter the size of the array: ";
    cin >> size;

    int *arr = new int[size];

    cout << "Enter " << size << " elements: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    cout << "Enter the item to search: ";
    cin >> item;

    for (int i = 0; i < size; i++) {
        if (arr[i] == item) {
            found = i;
            break;
        }
    }

    if (found != -1) {
        cout << "Item found at index: " << found << endl;
    } else {
        cout << "Item not found in the list." << endl;
    }

    delete[] arr;

    return 0;
}

