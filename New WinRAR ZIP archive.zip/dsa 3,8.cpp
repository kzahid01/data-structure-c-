#include <iostream>
using namespace std;

int main() {
    int a, b;
    int* ptrA;
    int* ptrB;

    cout << "Enter an integer for a: ";
    cin >> a;

    cout << "Enter an integer for b: ";
    cin >> b;

    ptrA = &a;
    ptrB = &b;

    cout << "Value of a using pointer ptrA: " << *ptrA << endl;
    cout << "Value of b using pointer ptrB: " << *ptrB << endl;

    return 0;
}

