#include <iostream>
using namespace std;

int main() {
    int rows, cols;
    cout<<"enter rows and colum " <<endl ;
    cin >>  rows >> cols;
    int arr[rows][cols];
    int sum ;
 int mul ;
cout<<"enter value to array"<<endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cin >> arr[i][j];
            sum += arr[i][j];
            mul *= arr[i][j];
        }
    }

    double avg = (double)sum / (rows * cols);

    cout << "Sum: " << sum << endl;
    cout << "Multiplication: " << mul << endl;
    cout << "Average: " << avg << endl;

    return 0;
}

