#include <iostream>
using namespace std;

int main() {
	cout<<"enter x,y"<<endl;
    int x, y;
    cin >> x >> y;

    int *p1 = &x;
    int *p2 = &y;

    int temp = *p1;
    *p1 = *p2;
    *p2 = temp;

    cout << "After swapping: " << endl;
    cout << "x = " << x << endl;
    cout << "y = " << y << endl;

    return 0;
}

