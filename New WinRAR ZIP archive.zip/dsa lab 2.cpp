#include<iostream>
using namespace std;
int main()
{
	int student_age[10];
	int largest=0;
	cout<<"enter age of 10 students"<<endl;
	for(int i=0;i<10;i++)
	{
	cin>>student_age[i];
	if (largest>student_age[i])
	{
	
		
	}
	else
	largest=student_age[i];
	cout<<endl;
	}
	cout<<"largest age of student is="<<largest<<endl;

}
