#include <iostream>
#include <string>

using namespace std;

string reverseString(string str) {
    int n = str.length();
    char stack[n];
    int top = -1;

    for (int i = 0; i < n; i++) {
        top++;
        stack[top] = str[i];
    }

    string reversedStr = "";
    while (top >= 0) {
        reversedStr += stack[top];
        top--;
    }

    return reversedStr;
}

int main() {
    string str;
    cout << "Enter a string: ";
    getline(cin, str);
    string reversedStr = reverseString(str);
    cout << "Reversed string: " << reversedStr << endl;
    return 0;
}

