#include <iostream>
using namespace std;

int main() {
    int size;

    cout << "Enter the size of the arrays: ";
    cin >> size;

    int *arr1 = new int[size];
    int *arr2 = new int[size];
    int *arr3 = new int[size];
    int *result = new int[size];

    for (int i = 0; i < size; i++) {
        cin >> arr1[i];
    }

    for (int i = 0; i < size; i++) {
        cin >> arr2[i];
    }

    for (int i = 0; i < size; i++) {
        cin >> arr3[i];
    }

    for (int i = 0; i < size; i++) {
        result[i] = arr1[i] + arr2[i] + arr3[i];
    }

    cout << "Resultant array: ";
    for (int i = 0; i < size; i++) {
        cout << result[i] << " ";
    }
    cout << endl;

    delete[] arr1;
    delete[] arr2;
    delete[] arr3;
    delete[] result;

    return 0;
}

