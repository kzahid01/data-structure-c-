#include <iostream>
using namespace std;

int main() {
    const int rows = 3, cols = 4;
    int arr[rows][cols] = {
        {10, 20, 30, 40},
        {50, 60, 70, 80},
        {90, 100, 110, 120}
    };

    int total = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            total += arr[i][j];
        }
    }
    
    double average = (double)total / (rows * cols);
    
    int row; cout<<"row"<<endl;
    cin >> row;
    int rowTotal = 0;
    for (int j = 0; j < cols; j++) {
        rowTotal += arr[row][j];
    }
    
    int col;cout<<"col"<<endl;
    cin >> col;
    int colTotal = 0;
    for (int i = 0; i < rows; i++) {
        colTotal += arr[i][col];
    }

    int highestInRow = arr[row][0];
    for (int j = 1; j < cols; j++) {
        if (arr[row][j] > highestInRow) {
            highestInRow = arr[row][j];
        }
    }

    int highestInCol = arr[0][col];
    for (int i = 1; i < rows; i++) {
        if (arr[i][col] > highestInCol) {
            highestInCol = arr[i][col];
        }
    }

    cout << "Total of all elements: " << total << endl;
    cout << "Average of all elements: " << average << endl;
    cout << "Total of row " << row << ": " << rowTotal << endl;
    cout << "Total of column " << col << ": " << colTotal << endl;
    cout << "Highest in row " << row << ": " << highestInRow << endl;
    cout << "Highest in column " << col << ": " << highestInCol << endl;

    return 0;
}

